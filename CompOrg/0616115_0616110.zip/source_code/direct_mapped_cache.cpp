#include <iostream>
#include <stdio.h>
#include <math.h>

using namespace std;

struct cache_content
{
	bool v;
	unsigned int tag;
    // unsigned int	data[16];
};

const int K = 1024;
string filename="";
string filenames[2] = {"./DCACHE.txt","./ICACHE.txt"};

double log2(double n)
{  
    // log(n) / log(2) is log2.
    return log(n) / log(double(2));
}


void simulate(int cache_size, int block_size)
{
    double total = 0,miss = 0;

	unsigned int tag, index, x;

    // Cache line should be the same as Cache block
	int offset_bit = (int)log2(block_size);//index of word inside block
	int index_bit = (int)log2(cache_size / block_size);
	int line = cache_size >> (offset_bit);//amount of lines is equal to the cache size divided by the size of each block  this then yields the amount of blocks(i think)

	cache_content *cache = new cache_content[line];//yup
	
    cout << "\t\tcache line(more like amoutn of blocks): " << line << endl;

	for(int j = 0; j < line; j++)
		cache[j].v = false;
	
    FILE *fp = fopen(filename.c_str(), "r");  // read file
	while(fscanf(fp, "%x", &x) != EOF)
    {
		// cout << hex << x << " "<<endl;
		index = (x >> offset_bit) & (line - 1);
		tag = x >> (index_bit + offset_bit);
		if(cache[index].v && cache[index].tag == tag){
            total++;
			cache[index].v = true;    // hit
        }else
        {
            total++;
            miss++;
            // cout << "\t Miss"<<endl;
			cache[index].v = true;  // miss
			cache[index].tag = tag;
		}
	}
    // cout << endl<<"Counter "<<total<<endl;
    // cout << endl<<dec<<"Miss "<<miss<<endl;
    // cout << endl<<"Hit "<<(total-miss)<<endl;

    //DIsplay miss rate
    float missrate = (miss/total)*100;
    cout <<"\t\tMiss rate : "<<missrate<<endl;
    // cout << endl<<"Hit rate : "<<dec<<((total-miss)/total)*100<<endl;
    //

	fclose(fp);

	delete [] cache;
}
	
int main()
{
	// Let us simulate 4KB cache with 16B blocks
	// simulate(4 * K, 16);
    int csizes[4] = {4,16,64,256};
    int blsizes[5] = {16,32,64,128,256};
        for(int i = 0 ; i <2;i++){
            filename = filenames[i];
            cout <<endl<< "---"<<endl;
            cout << "Results for file : "<<filename<<endl;
            cout << "---"<<endl;
            for(int cs_index = 0;cs_index<4;cs_index++){
                cout << "Results for cache size : "<<csizes[cs_index]<<endl;
                for(int bl_index = 0;bl_index<5;bl_index++){
                    cout << "\tBlock size: " << blsizes[bl_index]<<endl;
                    simulate(csizes[cs_index]*K,blsizes[bl_index]);
                }
            }
        }
}

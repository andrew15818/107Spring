#include <iostream>
#include <climits>
#include <stdio.h>
#include <math.h>

using namespace std;

struct cache_content//i think this is a single word
{
	bool v;
	unsigned int tag;
    unsigned int timestamp;
    // unsigned int	data[16]; pff we dont care about this
};

const int K = 1024;
const int BLOCK_SIZE = 64;

string filenames[2] = {"../test/LU.txt","../test/RADIX.txt"};
string filename;
double log2(double n)
{  
    // log(n) / log(2) is log2.
    return log(n) / log(double(2));
}


void simulate(int cache_size, int block_size,int n)
{
    double total = 0,miss = 0;

	unsigned int tag, index, x;

    cache_size /= n;//TODO not so sure about this bad boi
	int offset_bit = (int)log2(block_size);//index of word inside block
	int index_bit = (int)log2(cache_size / block_size);
	int setNo = cache_size >> (offset_bit);

	cache_content **cache = new cache_content *[setNo];//Two value array
	
    // cout << "Amount of blocks : "<< setNo << " and the amount of words blocks inside each set: "<<n<<endl;

	for(int i = 0; i < setNo; i++){
        //initialize for cols
        cache[i] = new cache_content[n];
        for(int j = 0; j < n; j++){
            cache[i][j].v = false;
            cache[i][j].timestamp=0;
        }
    }
    FILE *fp = fopen(filename.c_str(), "r");  // read file
    //Values for realization(words make no sense to me this alte i know, my apologies)
    size_t timestamp = 0;
    bool hitthatboi = false;
    unsigned int smallestTimestamp;
	while(fscanf(fp, "%x", &x) != EOF)
    {
		// cout << hex << x << " "<<endl;
		index = (x >> offset_bit) & (setNo - 1);
		tag = x >> (index_bit + offset_bit);

        hitthatboi = false;
        timestamp++;//we simply set the timestamp to the iteration of the read
        //Check inside the set 
        for(int i = 0;i<n;i++){
            if(cache[index][i].v && cache[index][i].tag == tag){
                total++;
                cache[index][i].v = true;    // hit
                cache[index][i].timestamp = timestamp;    // hit
                hitthatboi=true;
            }
        }
		if(!hitthatboi)//if we didnt get a hit
        {//Aqui es donde deberia de ver
            //Entoncesahora toca ver el least used 
            cache_content * leastUsed;//place holder
            smallestTimestamp = UINT_MAX;
            for(int i=0;i<n;i++){
                if(cache[index][i].timestamp < smallestTimestamp){
                    leastUsed = &cache[index][i];
                    smallestTimestamp = cache[index][i].timestamp;
                }
            }
            //Now we modify that boi:
            leastUsed->timestamp = timestamp;
            leastUsed->tag = tag;
            leastUsed->v = true;

            total++;
            miss++;
		}
	}
    float missrate = (miss/total)*100;
    cout <<"\t\tMiss rate : "<<missrate<<endl;

	fclose(fp);

    for (int i =0;i<setNo;i++)
        delete[] cache[i];
	delete [] cache;
}

int getReqBits(int cacheSize, int associ){
    cacheSize /= associ;//TODO not so sure about this bad boi
	int offset_bit = (int)log2(BLOCK_SIZE);//index of word inside block
	int index_bit = (int)log2(cacheSize / BLOCK_SIZE);
	int setNo = cacheSize >> (offset_bit);

    int tagSize = 32-(offset_bit+index_bit);
    int finalSize = setNo*associ*(1+tagSize+BLOCK_SIZE*8);

    return finalSize;
}
int main()
{
	// Let us simulate 4KB cache with 16B blocks
	// simulate(4 * K, 16);
    int csizes[6] = {1,2,4,8,16,32};
    int ass_sizes[4] = {1,2,4,8};//not that kind of ass silly 

    for(int i = 0 ; i <2;i++){
        filename = filenames[i];
        cout << "Results for file : "<<filename<<endl<<endl;
        for(int cs_index = 0;cs_index<6;cs_index++){
            cout << "Results for cache size : "<<csizes[cs_index]<<"*K"<<endl;
            for(int ass_index = 0;ass_index<4;ass_index++){
                cout << "\tAssociativity " << ass_sizes[ass_index]<<endl;
                simulate(csizes[cs_index]*K,BLOCK_SIZE,ass_sizes[ass_index]);
            }
        }
    }

    //Show required Bits
    
    for(int cs_index = 0;cs_index<6;cs_index++){
        for(int ass_index = 0;ass_index<4;ass_index++){
        cout << "Cache size : "<<csizes[cs_index]<<"*K\t";
            cout << ass_sizes[ass_index]<< "-way" << endl;
            cout << "\tReq bits:"<<getReqBits(csizes[cs_index]*K,ass_sizes[ass_index])<<endl;
        }
    }
}

SELECT Id, matchID, damageDealt FROM player_statistic
WHERE damageDealt>=2000 AND damageDealt<=2010;
